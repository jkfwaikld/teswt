(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_9c4533b5._.js",
  "static/chunks/node_modules_78573e2c._.js"
],
    source: "dynamic"
});
