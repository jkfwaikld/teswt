(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c6ef1758._.js",
  "static/chunks/node_modules_lodash_e947804c._.js",
  "static/chunks/node_modules_recharts_es6_91b77097._.js",
  "static/chunks/node_modules_@radix-ui_4431c1d6._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_732172da._.js"
],
    source: "dynamic"
});
